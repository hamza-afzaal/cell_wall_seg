import numpy as np
import scipy.stats as st
import seaborn as sns
import matplotlib.pyplot as plt
import math


def calc_ci(data):
    mean = data.mean(axis=0)
    ci = []
    for index in range(len(mean)):
        ci.append(st.t.interval(0.95, len(data[:, index]) - 1, loc=mean[index],
                                scale=st.sem(data[:, index]) / math.sqrt(len(mean))))
    return mean.tolist(), np.abs(np.array(ci)).T.tolist()


overall_label = ["IOU", "Precision", "Recall", "F1 Score"]
overall_diff_label = ["V/H", "V/HF", "H/HF"]
overall_color = ['#deebf7', '#9ecae1', '#3182bd', '#08519c']
overall_diff_color = ['#f0f0f0', '#bdbdbd', '#636363']

participant_times_extrema = np.array([[140, 117, 51], [102, 122, 131], [166, 243, 153]])
participant_times_quiver = np.array([[202, 133, 68], [147, 155, 117], [131, 200, 171]])
participant_times_abrasion = np.array([[72, 53, 37], [135, 161, 156], [142, 199, 205]])

overall_time_avg = np.stack((participant_times_extrema, participant_times_abrasion, participant_times_quiver))
overall_time_avg = overall_time_avg.mean(axis=0)


overall_mean, overall_std = calc_ci(overall_time_avg)
# overall_mean = overall_time_avg.mean(axis=0)
# overall_std = overall_time_avg.std(axis=0)
time_diff_overall = []
for value in overall_time_avg:
    time_diff_overall.append([value[0] - value[1], value[0] - value[2], value[2] - value[1]])
time_diff_overall = np.array(time_diff_overall)
overall_diff_mean, overall_diff_std = calc_ci(time_diff_overall)
# overall_diff_mean = time_diff_overall.mean(axis=0)
# overall_diff_std = time_diff_overall.std(axis=0)
# overall_mean = [57, 75, 98]
# overall_std = [2.3, 4.2, 8.5]
# overall_colors = ['#bcbddc', '#756bb1', '#756bb1']
# v_s_diff = [overall_mean]


extrema_mean, extrema_std = calc_ci(participant_times_extrema)
# extrema_mean = participant_times_extrema.mean(axis=0)
# extrema_std = participant_times_extrema.std(axis=0)
time_diff_extrema = []
for value in participant_times_extrema:
    time_diff_extrema.append([value[0] - value[1], value[0] - value[2], value[2] - value[1]])
time_diff_extrema = np.array(time_diff_extrema)
extrema_diff_mean, extrema_diff_std = calc_ci(time_diff_extrema)
# extrema_diff_mean = time_diff_extrema.mean(axis=0)
# extrema_diff_std = time_diff_extrema.std(axis=0)
# extrema_colors = ['#deebf7', '#9ecae1', '#3182bd']


quiver_mean, quiver_std = calc_ci(participant_times_quiver)
# quiver_mean = participant_times_quiver.mean(axis=0)
# quiver_std = participant_times_quiver.std(axis=0)
time_diff_quiver = []
for value in participant_times_quiver:
    time_diff_quiver.append([value[0] - value[1], value[0] - value[2], value[2] - value[1]])
time_diff_quiver = np.array(time_diff_quiver)
quiver_diff_mean, quiver_diff_std = calc_ci(time_diff_quiver)
# quiver_diff_mean = time_diff_quiver.mean(axis=0)
# quiver_diff_std = time_diff_quiver.std(axis=0)
# extrema_colors = ['#deebf7', '#9ecae1', '#3182bd']
#  = [0.854, 0.907, 0.913]
#  = [0.076, 0.026, 0.094]
# quiver_colors = ['#f0f0f0', '#bdbdbd', '#636363']


abrasion_mean, abrasion_std = calc_ci(participant_times_abrasion)
# abrasion_mean = participant_times_abrasion.mean(axis=0)
# abrasion_std = participant_times_abrasion.std(axis=0)
time_diff_abrasion = []
for value in participant_times_abrasion:
    time_diff_abrasion.append([value[0] - value[1], value[0] - value[2], value[2] - value[1]])
time_diff_abrasion = np.array(time_diff_abrasion)
abrasion_diff_mean, abrasion_diff_std = calc_ci(time_diff_abrasion)
# abrasion_diff_mean = time_diff_abrasion.mean(axis=0)
# abrasion_diff_std = time_diff_abrasion.std(axis=0)
# abrasion_mean = [0.803, 0.849, 0.853]
# abrasion_std = [0.098, 0.044, 0.073]
# abrasion_colors = ['#fee0d2', '#fc9272', '#de2d26']

sns.set_theme()
sns.set_context("paper")

#################################################################
# ## FIRST ROW
#################################################################

fig, (ax1, ax2, ax3) = plt.subplots(1, 3)  # , (ax5, ax6, ax7, ax8)
# ax1.bar(np.arange(len(overall_label)), overall_mean, yerr=overall_std, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_color, edgecolor='black')
# ax1.set_ylabel("Time (seconds)")
# ax1.set_xticks(np.arange(len(overall_label)))
# ax1.set_xticklabels(overall_label)
# ax1.set_title("Overall")
# ax1.set_aspect(19)
# ax1.yaxis.grid(True)

#fee5d9
#fcae91
#fb6a4a
#cb181d


#edf8e9
#bae4b3
#74c476
#238b45


model_2d_mean = [0.698200, 0.800717, 0.852769, 0.814432]
model_2d_std = [0.118956, 0.066242, 0.137091, 0.114456]

ax1.bar(np.arange(len(overall_label)), model_2d_mean, yerr=model_2d_std, align='center', alpha=0.9, ecolor='black',
        capsize=4, color=overall_color, edgecolor='black')
# ax2.set_ylabel("Time (seconds)")
ax1.set_xticks(np.arange(len(overall_label)))
ax1.set_xticklabels(overall_label, rotation='vertical')
ax1.set_title("2D-Unet: Combo Loss")
ax1.set_aspect('auto')
ax1.set_ylim([0.57, 1.0])
ax1.yaxis.grid(True)

model_2d_mean = [0.804343, 0.868687, 0.917888, 0.889149]
model_2d_std = [0.079030, 0.079308, 0.056022, 0.056069]
overall_color = ['#fee5d9', '#fcae91', '#fb6a4a', '#cb181d']

ax2.bar(np.arange(len(overall_label)), model_2d_mean, yerr=model_2d_std, align='center', alpha=0.9, ecolor='black',
        capsize=4, color=overall_color, edgecolor='black')
# ax2.set_ylabel("Time (seconds)")
ax2.set_xticks(np.arange(len(overall_label)))
ax2.set_xticklabels(overall_label, rotation='vertical')
ax2.set_title("3D-Unet: Combo Loss")
ax2.set_aspect('auto')
ax2.set_ylim([0.57, 1.0])
ax2.yaxis.grid(True)

model_2d_mean = [0.794843, 0.837759, 0.941832, 0.882815]
model_2d_std = [0.078619, 0.086177, 0.033220, 0.067543]
overall_color = ['#edf8e9', '#bae4b3', '#74c476', '#238b45']

ax3.bar(np.arange(len(overall_label)), model_2d_mean, yerr=model_2d_std, align='center', alpha=0.9, ecolor='black',
        capsize=4, color=overall_color, edgecolor='black')
# ax2.set_ylabel("Time (seconds)")
ax3.set_xticks(np.arange(len(overall_label)))
ax3.set_xticklabels(overall_label, rotation='vertical')
ax3.set_title("3D-Unet: Dice+Focal Loss")
ax3.set_aspect('auto')
ax3.set_ylim([0.57, 1.0])
ax3.yaxis.grid(True)
#
# ax3.bar(np.arange(len(overall_label)), quiver_mean, yerr=quiver_std, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_color, edgecolor='black')
# # ax3.set_ylabel("Time (seconds)")
# ax3.set_xticks(np.arange(len(overall_label)))
# ax3.set_xticklabels(overall_label)
# ax3.set_title("TaskQuiver")
# ax3.yaxis.grid(True)
#
# ax4.bar(np.arange(len(overall_label)), abrasion_mean, yerr=abrasion_std, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_color, edgecolor='black')
# ax4.set_title("TaskAbrasion")
# ax4.set_xticks(np.arange(len(overall_label)))
# ax4.set_xticklabels(overall_label)
# # ax4.set_title("F1 Score")
# ax4.yaxis.grid(True)
# # fig.autofmt_xdate()
#
# #################################################################
# # ## SECOND ROW
# #################################################################
#
# ax5.bar(np.arange(len(overall_diff_label)), overall_diff_mean, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_diff_color, edgecolor='black')
# ax5.set_ylabel("Time (seconds)")
# ax5.set_xticks(np.arange(len(overall_diff_label)))
# ax5.set_xticklabels(overall_diff_label)
# ax5.yaxis.grid(True)
# ax5.errorbar(np.arange(len(overall_diff_label)), overall_diff_mean, yerr=overall_diff_std, fmt="o", color="black")
#
# ax6.bar(np.arange(len(overall_diff_label)), extrema_diff_mean, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_diff_color, edgecolor='black')
# # ax6.set_title("TaskAbrasion")
# ax6.set_xticks(np.arange(len(overall_diff_label)))
# ax6.set_xticklabels(overall_diff_label)
# # ax4.set_title("F1 Score")
# ax6.yaxis.grid(True)
# ax6.errorbar(np.arange(len(overall_diff_label)), extrema_diff_mean, yerr=extrema_diff_std, fmt="o", color="black")
# # fig.autofmt_xdate()
#
# ax7.bar(np.arange(len(overall_diff_label)), quiver_diff_mean, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_diff_color, edgecolor='black')
# # ax7.set_title("TaskAbrasion")
# ax7.set_xticks(np.arange(len(overall_diff_label)))
# ax7.set_xticklabels(overall_diff_label)
# # ax4.set_title("F1 Score")
# ax7.yaxis.grid(True)
# ax7.errorbar(np.arange(len(overall_diff_label)), quiver_diff_mean, yerr=quiver_diff_std, fmt="o", color="black")
# # fig.autofmt_xdate()
#
# ax8.bar(np.arange(len(overall_diff_label)), abrasion_diff_mean, align='center', alpha=0.9, ecolor='black',
#         capsize=4, color=overall_diff_color, edgecolor='black')
# # ax8.set_title("TaskAbrasion")
# ax8.set_xticks(np.arange(len(overall_diff_label)))
# ax8.set_xticklabels(overall_diff_label)
# # ax4.set_title("F1 Score")
# ax8.yaxis.grid(True)
# ax8.errorbar(np.arange(len(overall_diff_label)), abrasion_diff_mean, yerr=abrasion_diff_std, fmt="o", color="black")
# # fig.autofmt_xdate()


#################################################################
# ## ENDING
#################################################################

plt.tight_layout(rect=[0, 0.03, 1, 0.95], pad=1)
# plt.suptitle("Segmentation Model Comparison With Different Params", fontsize='large')
plt.savefig('bar_plot.png')
plt.show()
